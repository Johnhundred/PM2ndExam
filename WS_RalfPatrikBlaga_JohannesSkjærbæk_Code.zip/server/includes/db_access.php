<?php

//This file is not uploaded to github. We will need to send it around manually.
//Any changes will have to be sent around manually.
//This is, obviously, for security reasons.

//While unnecessary for development, for production, the DB user we connect with has no need to for privileges other than SELECT, UPDATE, DELETE and INSERT. For security reasons, the active DB user on live deployment should not have any other privileges than the 3 mentioned above.

//In a live deployment, it is a good idea to locate this file (and all other includes, really. Any kind of file you can, really) OUTSIDE of the web server's root, but this may not be possible depending on server setup.

/* ******************** DB LOGIN DETAILS & SETTINGS ******************** */


//websec server/online details
//define("HOST", "localhost"); // The host name.
//define("DB_TYPE", "mysql"); // The database type.
//define("USER", "quizgame"); // The database username.
//define("PASSWORD", "John Ralf 2!!"); // The database password.
//define("DATABASE", "quizgame"); // The database name.
//define("PDO_HOST_STRING", "mysql:host=localhost;dbname=quizgame"); // The host string for the PDO object.

//PARTICLEDESIGNS server/online details
//define("HOST", "localhost"); // The host name.
//define("DB_TYPE", "mysql"); // The database type.
//define("USER", "particle_quiz"); // The database username.
//define("PASSWORD", "John Ralf 2!!"); // The database password.
//define("DATABASE", "particle_quizgame"); // The database name.
//define("PDO_HOST_STRING", "mysql:host=localhost;dbname=particle_quizgame"); // The host string for the PDO object.

//local details
define("HOST", "localhost"); // The host name.
define("DB_TYPE", "mysql"); // The database type.
define("USER", "root"); // The database username.
define("PASSWORD", ""); // The database password.
define("DATABASE", "quizgame"); // The database name.
define("PDO_HOST_STRING", "mysql:host=localhost;dbname=quizgame"); // The host string for the PDO object.

// Not currently used
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
define("LOGIN_ATTEMPTS_ALLOWED", 5); // Default attempts to login.

// Whether we use HTTPS or not
define("SECURE", false);

// Session lifetime in seconds
define("SESSION_LIFETIME", 1800);

// Set game start time in seconds
define("GAME_START_TIME", 20);

// Whether we encrypt the log or not, what the key is, what the method is
define("ENCRYPT_LOG", false);
define("LOG_KEY", "Weeb!Lord859!");
define("LOG_METHOD", "aes-256-ctr");

