<?php

include_once 'server/includes/inc.php';

secure_session_start();

include_once 'modules/head.php';
include_once 'modules/navbar.php';

?>

    <div class="center-block logo logo-md">
        <img src="assets/img/logo.png">
    </div>


    <h2 class="construction margin-centerer">LEADERBOARD</h2>
    <h3 class="construction margin-centerer">This page is still under construction!</h3>


<?php

include_once 'modules/footer.php';

?>