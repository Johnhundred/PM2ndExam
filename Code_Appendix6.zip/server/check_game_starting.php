<?php

include_once 'includes/inc2.php';

$sData = $_POST['data'];
$jData = json_encode($sData);
$jData = json_decode($jData);
$id = htmlentities(filter_var($jData->id, FILTER_SANITIZE_STRING));
$time = intval(time());

try{
    $stmt = $pdo->prepare("SELECT * FROM active_games WHERE game_id = :id");
    $stmt->bindValue(":id", $id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row['starting_game'] != NULL){
        $starting = intval($row['starting_game']);
        if($starting > $time){
            echo htmlentities($row['starting_game']);
        }
    }
} catch(Exception $e){
    echo $e->getMessage();
}

?>